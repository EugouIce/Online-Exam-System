-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2025 at 11:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `exam_results`
--

CREATE TABLE `exam_results` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `section` varchar(50) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `student_answer` varchar(1) DEFAULT NULL,
  `correct_answer` varchar(1) DEFAULT NULL,
  `is_correct` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `exam_results`
--

INSERT INTO `exam_results` (`id`, `student_name`, `student_id`, `section`, `question_id`, `student_answer`, `correct_answer`, `is_correct`) VALUES
(105, 'Marjorie Ruiz', '09465500950', 'Matalino', 7, 'C', 'C', 1),
(106, 'Marjorie Ruiz', '09465500950', 'Matalino', 8, 'A', 'A', 1),
(107, 'Marjorie Ruiz', '09465500950', 'Matalino', 9, 'B', 'B', 1),
(108, 'Marjorie Ruiz', '09465500950', 'Matalino', 10, 'D', 'D', 1),
(109, 'Marjorie Ruiz', '09465500950', 'Matalino', 11, 'B', 'B', 1),
(110, 'matt vincent t ruiz', '1365580019', '7 sampaguita', 7, 'C', 'C', 1),
(111, 'matt vincent t ruiz', '1365580019', '7 sampaguita', 8, 'B', 'A', 0),
(112, 'matt vincent t ruiz', '1365580019', '7 sampaguita', 9, 'B', 'B', 1),
(113, 'matt vincent t ruiz', '1365580019', '7 sampaguita', 10, 'B', 'D', 0),
(114, 'matt vincent t ruiz', '1365580019', '7 sampaguita', 11, 'B', 'B', 1),
(115, 'Joshua Isaiah T. Ruiz', 'CA202409352', 'LFCA133N002', 7, 'C', 'C', 1),
(116, 'Joshua Isaiah T. Ruiz', 'CA202409352', 'LFCA133N002', 8, 'A', 'A', 1),
(117, 'Joshua Isaiah T. Ruiz', 'CA202409352', 'LFCA133N002', 9, 'B', 'B', 1),
(118, 'Joshua Isaiah T. Ruiz', 'CA202409352', 'LFCA133N002', 10, 'D', 'D', 1),
(119, 'Joshua Isaiah T. Ruiz', 'CA202409352', 'LFCA133N002', 11, 'B', 'B', 1),
(130, 'jovel lapiz', 'CA202409352', 'LFCA133N002', 9, 'B', NULL, 1),
(131, 'jovel lapiz', 'CA202409352', 'LFCA133N002', 11, 'B', NULL, 1),
(132, 'jovel lapiz', 'CA202409352', 'LFCA133N002', 10, 'D', NULL, 1),
(133, 'jovel lapiz', 'CA202409352', 'LFCA133N002', 7, 'C', NULL, 1),
(134, 'jovel lapiz', 'CA202409352', 'LFCA133N002', 8, 'A', NULL, 1),
(135, 'Irish', 'ca20242135', 'LFCA133N002', 8, 'A', NULL, 1),
(136, 'Irish', 'ca20242135', 'LFCA133N002', 10, 'D', NULL, 1),
(137, 'Irish', 'ca20242135', 'LFCA133N002', 7, 'C', NULL, 1),
(138, 'Irish', 'ca20242135', 'LFCA133N002', 9, 'B', NULL, 1),
(139, 'Irish', 'ca20242135', 'LFCA133N002', 11, 'B', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `online_exam`
--

CREATE TABLE `online_exam` (
  `adminID` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `online_exam`
--

INSERT INTO `online_exam` (`adminID`, `password`) VALUES
('eugou', 'admin123'),
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question` text NOT NULL,
  `choice_a` varchar(255) NOT NULL,
  `choice_b` varchar(255) NOT NULL,
  `choice_c` varchar(255) NOT NULL,
  `choice_d` varchar(255) NOT NULL,
  `correct_answer` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `choice_a`, `choice_b`, `choice_c`, `choice_d`, `correct_answer`) VALUES
(7, 'What is 9 x 7?', '62', '65', '63', '58', 'C'),
(8, 'What is 120 ÷ 6?', '20', '24', '15', '18', 'A'),
(9, 'What is 145 + 287?', '422', '432', '442', '452', 'B'),
(10, 'what is 162 ÷ 9?', '20', '22', '16', '18', 'D'),
(11, 'What is 38 x 6?', '218', '228', '238', '248', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `section` varchar(50) DEFAULT NULL,
  `exam_taken` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_id`, `full_name`, `section`, `exam_taken`) VALUES
(20, '09465500950', 'Marjorie Ruiz', 'Matalino', 0),
(21, '1365580019', 'matt vincent t ruiz', '7 sampaguita', 0),
(25, 'CA202409352', 'Joshua Isaiah T. Ruiz', 'LFCA133N002', 0),
(32, 'CA202409352', 'jovel lapiz', 'LFCA133N002', 0),
(33, 'ca20242135', 'Irish', 'LFCA133N002', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exam_results`
--
ALTER TABLE `exam_results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exam_results`
--
ALTER TABLE `exam_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
