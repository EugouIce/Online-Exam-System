    <?php
    session_start();
    include("../connection.php");

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION['student_name'] = $_POST['full_name'];
        $_SESSION['student_section'] = $_POST['section'];
        $_SESSION['student_id'] = $_POST['student_id'];

        
        $name = $_SESSION['student_name'];
        $section = $_SESSION['student_section'];
        $student_id = $_SESSION['student_id'];

        $conn->query("INSERT INTO students (student_id, full_name, section) 
                    VALUES ('$student_id', '$name', '$section')");

        
        header("Location: take_exam.php"); 
        exit();
    }
    ?>

    
    <!DOCTYPE html>
    <html>
    <head>
    <title>Start Exam</title>
    </head>
    <body>
    <h2>Online Examination</h2>
    <form method="post">
        <input type="text" name="full_name" placeholder="Full Name" required><br>
        <input type="text" name="section" placeholder="Section" required><br>
        <input type="text" name="student_id" placeholder="Student Number" required><br>
        <input type="submit" value="Start Exam">
    </form>
    </body>
    </html>
