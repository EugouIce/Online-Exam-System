<?php
session_start();
$student_name = $_SESSION['student_name'] ?? 'Student';
$score = $_SESSION['last_score'] ?? 0;
$total = $_SESSION['total_questions'] ?? 0;
?>

<!DOCTYPE html>
<html>
<head>
  <title>Exam Result</title>
</head>
<body>
  <h2>Thank you, <?php echo htmlspecialchars($student_name); ?>!</h2>
  <p>Your score: <?php echo $score . " / " . $total; ?></p>
  <div style="padding: 15px;">
    <a href="../return.php" style="
        display: inline-block;
        padding: 10px 20px;
        background-color: #3498db;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: background-color 0.3s;
    " onmouseover="this.style.backgroundColor='#2980b9'" onmouseout="this.style.backgroundColor='#3498db'">
        ⬅ Return
    </a>
</div>
</body>
</html>