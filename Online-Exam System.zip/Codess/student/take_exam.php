<?php
session_start();
if (!isset($_SESSION['exam_start_time'])) {
    $_SESSION['exam_start_time'] = time(); 
    $_SESSION['exam_duration'] = 10 * 60; 
}
$start_time = $_SESSION['exam_start_time'];
$duration = $_SESSION['exam_duration'];
$current_time = time();
$time_left = max(0, $start_time + $duration - $current_time); 
include("../connection.php");

if (!isset($_SESSION['question_index'])) {
    $_SESSION['question_index'] = 0;
    $_SESSION['answers'] = []; 
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_qid = $_POST['question_id'];
    $selected_answer = $_POST['answer'] ?? null;
    if ($selected_answer) {
        $_SESSION['answers'][$current_qid] = $selected_answer;
    }

    $_SESSION['question_index']++;

    
    header("Location: take_exam.php");
    exit();
}
if (!isset($_SESSION['random_questions'])) {
    $questions = $conn->query("SELECT * FROM questions");
    $questionsArray = [];

    while ($row = $questions->fetch_assoc()) {
        $questionsArray[] = $row;
    }

    shuffle($questionsArray); 
    $_SESSION['random_questions'] = $questionsArray;
}

$questionsArray = $_SESSION['random_questions'];


$totalQuestions = count($questionsArray);
$currentIndex = $_SESSION['question_index'] ?? 0;


if ($currentIndex >= $totalQuestions) {
    header("Location: submit_exam.php");
    exit();
}

$currentQuestion = $questionsArray[$currentIndex];
?>

<!DOCTYPE html>
<html>
<head>
  <style>
  * {
    user-select: none;
    -webkit-user-select: none;
    -ms-user-select: none;
  }
</style>
  <script>
  let timeLeft = <?php echo $time_left; ?>;

  function startTimer() {
    const timerDisplay = document.getElementById("timer");

    const countdown = setInterval(() => {
      const minutes = Math.floor(timeLeft / 60);
      const seconds = timeLeft % 60;

      timerDisplay.textContent = `Time Left: ${minutes}:${seconds < 10 ? '0' + seconds : seconds}`;

      if (timeLeft <= 0) {
        clearInterval(countdown);
        alert("Time's up! Submitting your exam.");
        document.forms[0].submit(); 
      }

      timeLeft--;
    }, 1000);
  }

  window.onload = startTimer;
</script>
  <title>Take Exam</title>
</head>
<body>
  <h2>Welcome, <?php echo $_SESSION['student_name']; ?>!</h2>
  <h3 id="timer" style="color:red;">Time Left: 10:00</h3>
  <h2>Question <?php echo $currentIndex + 1; ?> of <?php echo $totalQuestions; ?></h2>

<form method="post">
  <p><strong><?php echo $currentQuestion['question']; ?></strong></p>

  <input type="hidden" name="question_id" value="<?php echo $currentQuestion['id']; ?>">

  <label><input type="radio" name="answer" value="A" required> <?php echo $currentQuestion['choice_a']; ?></label><br>
  <label><input type="radio" name="answer" value="B"> <?php echo $currentQuestion['choice_b']; ?></label><br>
  <label><input type="radio" name="answer" value="C"> <?php echo $currentQuestion['choice_c']; ?></label><br>
  <label><input type="radio" name="answer" value="D"> <?php echo $currentQuestion['choice_d']; ?></label><br>

  <input type="submit" value="<?php echo ($currentIndex + 1 == $totalQuestions) ? 'Submit Exam' : 'Next'; ?>">
</form>
<script>
  
  document.addEventListener('contextmenu', e => e.preventDefault());

  
  document.addEventListener('copy', e => e.preventDefault());
  document.addEventListener('paste', e => e.preventDefault());

  
  document.addEventListener('keydown', function (e) {
    
    if ((e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J')) ||
        
        (e.ctrlKey && (e.key === 'u' || e.key === 's')) ||
        
        (e.key === 'F12')) {
      e.preventDefault();
    }
  });
</script>
</body>
</html>