<?php
include("../connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $question = $_POST['question'];
    $a = $_POST['choice_a'];
    $b = $_POST['choice_b'];
    $c = $_POST['choice_c'];
    $d = $_POST['choice_d'];
    $correct = strtoupper($_POST['correct_answer']);

    
    if (!empty($question) && !empty($a) && !empty($b) && !empty($c) && !empty($d) && in_array($correct, ['A', 'B', 'C', 'D'])) {
        $sql = "INSERT INTO questions (question, choice_a, choice_b, choice_c, choice_d, correct_answer)
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $question, $a, $b, $c, $d, $correct);

        if ($stmt->execute()) {
            
            header("Location: create_question.php?success=1");
            exit();
        } else {
            echo "<script>alert('Failed to add question.');</script>";
        }
    } else {
        echo "<script>alert('Please fill out all fields and choose a valid correct answer (A/B/C/D).');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
</head>
<body>
    <div style="padding: 15px;">
    <a href="dashboard.php" style="
        display: inline-block;
        padding: 10px 20px;
        background-color: #3498db;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: background-color 0.3s;
    " onmouseover="this.style.backgroundColor='#2980b9'" onmouseout="this.style.backgroundColor='#3498db'">
        ⬅ Back to Dashboard
    </a>
</div>
    <h2>Create New Question</h2>
    <?php
if (isset($_GET['success'])) {
    echo "<p style='color: green;'>✅ Question added successfully!</p>";
}
?>
<form method="post" action="">
    <label>Question:</label><br>
    <textarea name="question" required></textarea><br><br>

    <label>Choice A:</label><br>
    <input type="text" name="choice_a" required><br>

    <label>Choice B:</label><br>
    <input type="text" name="choice_b" required><br>

    <label>Choice C:</label><br>
    <input type="text" name="choice_c" required><br>

    <label>Choice D:</label><br>
    <input type="text" name="choice_d" required><br>

    <label>Correct Answer (A/B/C/D):</label><br>
    <input type="text" name="correct_answer" maxlength="1" required><br><br>

    <input type="submit" value="Create Question">
</form>
</body>
</html>