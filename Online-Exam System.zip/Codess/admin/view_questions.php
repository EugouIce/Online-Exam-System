<?php
include("../connection.php");


if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $conn->query("DELETE FROM questions WHERE id=$delete_id");
    header("Location: view_questions.php?deleted=1");
    exit();
}


if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $question = $_POST['question'];
    $a = $_POST['choice_a'];
    $b = $_POST['choice_b'];
    $c = $_POST['choice_c'];
    $d = $_POST['choice_d'];
    $correct = strtoupper($_POST['correct_answer']);

    if (!empty($question) && in_array($correct, ['A', 'B', 'C', 'D'])) {
        $stmt = $conn->prepare("UPDATE questions SET question=?, choice_a=?, choice_b=?, choice_c=?, choice_d=?, correct_answer=? WHERE id=?");
        $stmt->bind_param("ssssssi", $question, $a, $b, $c, $d, $correct, $id);
        $stmt->execute();
        header("Location: view_questions.php?updated=1");
        exit();
    }
}


$editData = null;
if (isset($_GET['edit_id'])) {
    $edit_id = $_GET['edit_id'];
    $result = $conn->query("SELECT * FROM questions WHERE id=$edit_id");
    if ($result->num_rows > 0) {
        $editData = $result->fetch_assoc();
    }
}


$questions = $conn->query("SELECT * FROM questions");
?>

<!DOCTYPE html>
<html>
<head>
    <title>View & Edit Questions</title>
    <style>
        body {
            font-family: Arial;
            padding: 20px;
        }
        table {
            width: 95%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }
        th {
            background-color: #444;
            color: white;
        }
        tr:nth-child(even) {
            background: #f3f3f3;
        }
        .btn-edit {
            background: orange;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn-delete {
            background: crimson;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
            margin-left: 5px;
        }
        .dashboard-link {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
    </style>
    <script>
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete this question?")) {
                window.location.href = "view_questions.php?delete_id=" + id;
            }
        }
    </script>
</head>
<body>

<a class="dashboard-link" href="dashboard.php">⬅ Back to Dashboard</a>

<?php if (isset($_GET['updated'])): ?>
    <p style="color: green;"><strong>✅ Question updated successfully!</strong></p>
<?php elseif (isset($_GET['deleted'])): ?>
    <p style="color: red;"><strong>🗑️ Question deleted successfully!</strong></p>
<?php endif; ?>

<?php if ($editData): ?>
    <h2>Edit Question</h2>
    <form method="post">
        <input type="hidden" name="id" value="<?= $editData['id']; ?>">
        <label>Question:</label><br>
        <textarea name="question" required><?= htmlspecialchars($editData['question']) ?></textarea><br><br>

        <label>Choice A:</label><br>
        <input type="text" name="choice_a" value="<?= $editData['choice_a'] ?>" required><br>

        <label>Choice B:</label><br>
        <input type="text" name="choice_b" value="<?= $editData['choice_b'] ?>" required><br>

        <label>Choice C:</label><br>
        <input type="text" name="choice_c" value="<?= $editData['choice_c'] ?>" required><br>

        <label>Choice D:</label><br>
        <input type="text" name="choice_d" value="<?= $editData['choice_d'] ?>" required><br>

        <label>Correct Answer (A/B/C/D):</label><br>
        <input type="text" name="correct_answer" value="<?= $editData['correct_answer'] ?>" maxlength="1" required><br><br>

        <input type="submit" name="update" value="Update Question">
    </form>
<?php endif; ?>

<h2>All Questions</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Question</th>
        <th>A</th>
        <th>B</th>
        <th>C</th>
        <th>D</th>
        <th>Correct</th>
        <th>Actions</th>
    </tr>
    <?php while($row = $questions->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['question']) ?></td>
            <td><?= $row['choice_a'] ?></td>
            <td><?= $row['choice_b'] ?></td>
            <td><?= $row['choice_c'] ?></td>
            <td><?= $row['choice_d'] ?></td>
            <td><strong><?= $row['correct_answer'] ?></strong></td>
            <td>
                <a class="btn-edit" href="view_questions.php?edit_id=<?= $row['id'] ?>">Edit</a>
                <a class="btn-delete" href="javascript:void(0);" onclick="confirmDelete(<?= $row['id'] ?>)">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
