<?php
include("../connection.php");


$selected_section = $_GET['section'] ?? '';
$search = trim($_GET['search'] ?? '');


$limit = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1);
$offset = ($page - 1) * $limit;


$section_result = $conn->query("SELECT DISTINCT section FROM exam_results");


$where_clauses = [];

if (!empty($selected_section)) {
    $where_clauses[] = "section = '" . $conn->real_escape_string($selected_section) . "'";
}
if (!empty($search)) {
    $escaped = $conn->real_escape_string($search);
    $where_clauses[] = "(student_name LIKE '%$escaped%' OR student_id LIKE '%$escaped%')";
}

$where_sql = '';
if (count($where_clauses) > 0) {
    $where_sql = " WHERE " . implode(" AND ", $where_clauses);
}


$count_query = "
    SELECT COUNT(*) AS total FROM (
        SELECT student_id, student_name, section
        FROM exam_results
        $where_sql
        GROUP BY student_id, student_name, section
    ) AS subquery
";
$count_result = $conn->query($count_query);
$total_students = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_students / $limit);


$query = "
    SELECT student_name, student_id, section, 
           SUM(is_correct) AS correct_answers, 
           COUNT(question_id) AS total_answers
    FROM exam_results
    $where_sql
    GROUP BY student_id, student_name, section
    ORDER BY correct_answers DESC
    LIMIT $limit OFFSET $offset
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Scores</title>
  <style>
    table {
      border-collapse: collapse;
      width: 80%;
      margin: 20px auto;
    }
    th, td {
      border: 1px solid #888;
      padding: 10px;
      text-align: center;
    }
    th {
      background-color: #f2f2f2;
    }
    h2 {
      text-align: center;
    }
    .filter-container, .pagination, .back-link {
      text-align: center;
      margin: 20px;
    }
    .pagination a {
      margin: 0 5px;
      text-decoration: none;
    }
    .pagination select {
      padding: 5px;
    }
  </style>
</head>
<body>

<h2>Student Scores</h2>

<div class="filter-container">
  <form method="GET" action="">
    <label for="section">Filter by Section:</label>
    <select name="section" id="section" onchange="this.form.submit()">
      <option value="">All Sections</option>
      <?php while ($row = $section_result->fetch_assoc()): ?>
        <option value="<?php echo $row['section']; ?>" <?php if ($row['section'] == $selected_section) echo 'selected'; ?>>
          <?php echo $row['section']; ?>
        </option>
      <?php endwhile; ?>
    </select>

    <input type="text" name="search" placeholder="Search name or ID" value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit">Search</button>
  </form>
</div>

<table>
  <tr>
    <th>Student Name</th>
    <th>Student ID</th>
    <th>Section</th>
    <th>Score</th>
  </tr>

  <?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?php echo $row['student_name']; ?></td>
        <td><?php echo $row['student_id']; ?></td>
        <td><?php echo $row['section']; ?></td>
        <td><?php echo $row['correct_answers'] . " / " . $row['total_answers']; ?></td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
    <tr>
      <td colspan="4">No results found.</td>
    </tr>
  <?php endif; ?>
</table>


<div class="pagination">
  <?php if ($page > 1): ?>
    <a href="?page=<?php echo $page - 1; ?>&section=<?php echo urlencode($selected_section); ?>&search=<?php echo urlencode($search); ?>">&laquo; Prev</a>
  <?php endif; ?>

  <?php for ($i = 1; $i <= $total_pages; $i++): ?>
    <a href="?page=<?php echo $i; ?>&section=<?php echo urlencode($selected_section); ?>&search=<?php echo urlencode($search); ?>" style="<?php echo $i == $page ? 'font-weight:bold; color:red;' : ''; ?>">
      <?php echo $i; ?>
    </a>
  <?php endfor; ?>

  <?php if ($page < $total_pages): ?>
    <a href="?page=<?php echo $page + 1; ?>&section=<?php echo urlencode($selected_section); ?>&search=<?php echo urlencode($search); ?>">Next &raquo;</a>
  <?php endif; ?>

  
  <form method="GET" style="display: inline;">
    <input type="hidden" name="section" value="<?php echo htmlspecialchars($selected_section); ?>">
    <input type="hidden" name="search" value="<?php echo htmlspecialchars($search); ?>">
    <label for="page_jump">Go to page:</label>
    <select name="page" id="page_jump" onchange="this.form.submit()">
      <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <option value="<?php echo $i; ?>" <?php if ($i == $page) echo 'selected'; ?>><?php echo $i; ?></option>
      <?php endfor; ?>
    </select>
  </form>
</div>

<div style="padding: 15px;">
    <a href="dashboard.php" style="
        display: inline-block;
        padding: 10px 20px;
        background-color: #3498db;
        color: white;
        text-decoration: none;  
        border-radius: 6px;
        font-weight: bold;
        transition: background-color 0.3s;
    " onmouseover="this.style.backgroundColor='#2980b9'" onmouseout="this.style.backgroundColor='#3498db'">
        ⬅ Back to Dashboard
    </a>
</div>

</body>
</html>
