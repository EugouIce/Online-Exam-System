<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial;
            padding: 40px;
            background: #f4f4f4;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
        }
        h2 {
            margin-bottom: 20px;
        }
        a {
            display: block;
            margin: 10px 0;
            font-size: 18px;
            text-decoration: none;
            color: #0056b3;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Welcome, Admin</h2>
    <a href="create_question.php">➕ Create New Question</a>
    <a href="view_questions.php">📄 View/Edit Questions</a>
    <a href="view_scores.php">📊 View Student Scores</a>
    <a href="../logout.php">🚪 Logout</a>
</div>
</body>
</html>